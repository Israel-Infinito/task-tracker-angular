Core classes for [Vanguard](https://vanguardapp.io) plugin support.

## Installation

To install the package just run the following command:

```
composer require vanguardapp/plugins
```

## License

This plugin is an open-source software licensed under the [MIT license](https://opensource.org/licenses/MIT). 