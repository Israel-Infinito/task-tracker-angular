<?php

return [
    'created_announcement' => 'Created an announcement #:id: :title',
    'updated_announcement' => 'Updated announcement #:id',
    'deleted_announcement' => 'Deleted announcement #:id',
];
