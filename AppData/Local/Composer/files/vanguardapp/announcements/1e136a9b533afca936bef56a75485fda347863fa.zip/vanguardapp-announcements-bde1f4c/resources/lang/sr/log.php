<?php

return [
    'created_announcement' => 'Kreirao je objavu #:id: :title.',
    'updated_announcement' => 'Ažurirao je objavu #:id.',
    'deleted_announcement' => 'Obrisao je objavu #:id.',
];
