<?php

return [
    'created_announcement' => 'Création de l\'annonce #:id: :title',
    'updated_announcement' => 'Mise à jour de l\'annonce #:id',
    'deleted_announcement' => 'Suppression de l\'annonce #:id',
];
