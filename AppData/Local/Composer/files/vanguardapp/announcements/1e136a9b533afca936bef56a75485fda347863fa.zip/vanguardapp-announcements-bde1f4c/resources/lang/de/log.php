<?php

return [
    'created_announcement' => 'Erstellt eine Ankündigung #:id: :title',
    'updated_announcement' => 'Aktualisierte Ankündigung #:id',
    'deleted_announcement' => 'Gelöschte Ankündigung #:id',
];
