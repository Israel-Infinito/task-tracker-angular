<script>
    var read_announcements_endpoint = "{{ route('announcements.read') }}";
</script>
<script src="{{ url("vendor/plugins/announcements/js/announcements.js") }}"></script>
