<link media="all"
      type="text/css"
      rel="stylesheet"
      href="{{ url(mix('/css/announcements.css', 'vendor/plugins/announcements')) }}">
