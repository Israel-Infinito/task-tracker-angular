<div class="card">
    <h6 class="card-header">
        @lang('Activity') (@lang('Last Two Weeks'))
    </h6>

    <div class="card-body">
        <div class="pt-4 px-3">
            <canvas id="myChart" height="400"></canvas>
        </div>
    </div>
</div>
